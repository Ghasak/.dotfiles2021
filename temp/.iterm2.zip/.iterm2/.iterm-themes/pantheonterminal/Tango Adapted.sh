#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Tango Adapted'
cursor-color='#000000'
foreground='#000000'
background='rgba(255,255,255,.95)'
palette='#000000:#ff0000:#59d600:#f0cb00:#00a2ff:#c17ecc:#00d0d6:#e6ebe1:#8f928b:#ff0013:#93ff00:#fff121:#88c9ff:#e9a7e1:#00feff:#f6f6f4'
COLORS
