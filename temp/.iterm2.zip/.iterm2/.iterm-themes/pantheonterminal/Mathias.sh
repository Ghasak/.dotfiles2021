#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Mathias'
cursor-color='#bbbbbb'
foreground='#bbbbbb'
background='rgba(0,0,0,.95)'
palette='#000000:#e52222:#a6e32d:#fc951e:#c48dff:#fa2573:#67d9f0:#f2f2f2:#555555:#ff5555:#55ff55:#ffff55:#5555ff:#ff55ff:#55ffff:#ffffff'
COLORS
