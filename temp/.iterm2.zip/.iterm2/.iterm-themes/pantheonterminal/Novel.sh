#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Novel'
cursor-color='#73635a'
foreground='#3b2322'
background='rgba(223,219,195,.95)'
palette='#000000:#cc0000:#009600:#d06b00:#0000cc:#cc00cc:#0087cc:#cccccc:#808080:#cc0000:#009600:#d06b00:#0000cc:#cc00cc:#0087cc:#ffffff'
COLORS
