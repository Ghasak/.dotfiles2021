#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Tomorrow Night Blue'
cursor-color='#ffffff'
foreground='#ffffff'
background='rgba(0,36,81,.95)'
palette='#000000:#ff9da4:#d1f1a9:#ffeead:#bbdaff:#ebbbff:#99ffff:#ffffff:#000000:#ff9da4:#d1f1a9:#ffeead:#bbdaff:#ebbbff:#99ffff:#ffffff'
COLORS
