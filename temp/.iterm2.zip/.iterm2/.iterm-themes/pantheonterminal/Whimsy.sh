#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Whimsy'
cursor-color='#b3b0d6'
foreground='#b3b0d6'
background='rgba(41,40,59,.95)'
palette='#535178:#ef6487:#5eca89:#fdd877:#65aef7:#aa7ff0:#43c1be:#ffffff:#535178:#ef6487:#5eca89:#fdd877:#65aef7:#aa7ff0:#43c1be:#ffffff'
COLORS
