#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='WildCherry'
cursor-color='#dd00ff'
foreground='#dafaff'
background='rgba(31,23,38,.95)'
palette='#000507:#d94085:#2ab250:#ffd16f:#883cdc:#ececec:#c1b8b7:#fff8de:#009cc9:#da6bac:#f4dca5:#eac066:#308cba:#ae636b:#ff919d:#e4838d'
COLORS
