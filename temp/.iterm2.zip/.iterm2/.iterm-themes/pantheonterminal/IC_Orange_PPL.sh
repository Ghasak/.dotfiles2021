#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='IC_Orange_PPL'
cursor-color='#fc531d'
foreground='#ffcb83'
background='rgba(38,38,38,.95)'
palette='#000000:#c13900:#a4a900:#caaf00:#bd6d00:#fc5e00:#f79500:#ffc88a:#6a4f2a:#ff8c68:#f6ff40:#ffe36e:#ffbe55:#fc874f:#c69752:#fafaff'
COLORS
