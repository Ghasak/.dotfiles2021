#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Tomorrow Night Bright'
cursor-color='#eaeaea'
foreground='#eaeaea'
background='rgba(0,0,0,.95)'
palette='#000000:#d54e53:#b9ca4a:#e7c547:#7aa6da:#c397d8:#70c0b1:#ffffff:#000000:#d54e53:#b9ca4a:#e7c547:#7aa6da:#c397d8:#70c0b1:#ffffff'
COLORS
