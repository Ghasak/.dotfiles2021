#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Purple Rain'
cursor-color='#ff271d'
foreground='#fffbf6'
background='rgba(33,8,74,.95)'
palette='#000000:#ff260e:#9be205:#ffc400:#00a2fa:#815bb5:#00deef:#ffffff:#565656:#ff4250:#b8e36e:#ffd852:#00a6ff:#ac7bf0:#74fdf3:#ffffff'
COLORS
