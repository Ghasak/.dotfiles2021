#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Sundried'
cursor-color='#ffffff'
foreground='#c9c9c9'
background='rgba(26,24,24,.95)'
palette='#302b2a:#a7463d:#587744:#9d602a:#485b98:#864651:#9c814f:#c9c9c9:#4d4e48:#aa000c:#128c21:#fc6a21:#7999f7:#fd8aa1:#fad484:#ffffff'
COLORS
