#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='CrayonPonyFish'
cursor-color='#68525a'
foreground='#68525a'
background='rgba(21,7,7,.95)'
palette='#2b1b1d:#91002b:#579524:#ab311b:#8c87b0:#692f50:#e8a866:#68525a:#3d2b2e:#c5255d:#8dff57:#c8381d:#cfc9ff:#fc6cba:#ffceaf:#b0949d'
COLORS
