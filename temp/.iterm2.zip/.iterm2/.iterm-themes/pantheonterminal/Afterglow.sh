#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Afterglow'
cursor-color='#d0d0d0'
foreground='#d0d0d0'
background='rgba(33,33,33,.95)'
palette='#151515:#ac4142:#7e8e50:#e5b567:#6c99bb:#9f4e85:#7dd6cf:#d0d0d0:#505050:#ac4142:#7e8e50:#e5b567:#6c99bb:#9f4e85:#7dd6cf:#f5f5f5'
COLORS
