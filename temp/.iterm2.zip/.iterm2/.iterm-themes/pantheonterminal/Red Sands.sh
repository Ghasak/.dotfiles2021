#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Red Sands'
cursor-color='#ffffff'
foreground='#d7c9a7'
background='rgba(122,37,30,.95)'
palette='#000000:#ff3f00:#00bb00:#e7b000:#0072ff:#bb00bb:#00bbbb:#bbbbbb:#555555:#bb0000:#00bb00:#e7b000:#0072ae:#ff55ff:#55ffff:#ffffff'
COLORS
