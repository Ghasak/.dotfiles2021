#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Pnevma'
cursor-color='#e4c9af'
foreground='#d0d0d0'
background='rgba(28,28,28,.95)'
palette='#2f2e2d:#a36666:#90a57d:#d7af87:#7fa5bd:#c79ec4:#8adbb4:#d0d0d0:#4a4845:#d78787:#afbea2:#e4c9af:#a1bdce:#d7beda:#b1e7dd:#efefef'
COLORS
