#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Wombat'
cursor-color='#bbbbbb'
foreground='#dedacf'
background='rgba(23,23,23,.95)'
palette='#000000:#ff615a:#b1e969:#ebd99c:#5da9f6:#e86aff:#82fff7:#dedacf:#313131:#f58c80:#ddf88f:#eee5b2:#a5c7ff:#ddaaff:#b7fff9:#ffffff'
COLORS
