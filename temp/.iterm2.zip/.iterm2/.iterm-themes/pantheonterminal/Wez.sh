#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Wez'
cursor-color='#53ae71'
foreground='#b3b3b3'
background='rgba(0,0,0,.95)'
palette='#000000:#cc5555:#55cc55:#cdcd55:#5555cc:#cc55cc:#7acaca:#cccccc:#555555:#ff5555:#55ff55:#ffff55:#5555ff:#ff55ff:#55ffff:#ffffff'
COLORS
