#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Highway'
cursor-color='#e0d9b9'
foreground='#ededed'
background='rgba(34,34,37,.95)'
palette='#000000:#d00e18:#138034:#ffcb3e:#006bb3:#6b2775:#384564:#ededed:#5d504a:#f07e18:#b1d130:#fff120:#4fc2fd:#de0071:#5d504a:#ffffff'
COLORS
