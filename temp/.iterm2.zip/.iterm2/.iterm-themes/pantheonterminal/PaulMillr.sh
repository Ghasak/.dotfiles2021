#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='PaulMillr'
cursor-color='#4d4d4d'
foreground='#f2f2f2'
background='rgba(0,0,0,.95)'
palette='#2a2a2a:#ff0000:#79ff0f:#e7bf00:#396bd7:#b449be:#66ccff:#bbbbbb:#666666:#ff0080:#66ff66:#f3d64e:#709aed:#db67e6:#7adff2:#ffffff'
COLORS
