#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Red Planet'
cursor-color='#c2b790'
foreground='#c2b790'
background='rgba(34,34,34,.95)'
palette='#202020:#8c3432:#728271:#e8bf6a:#69819e:#896492:#5b8390:#b9aa99:#676767:#b55242:#869985:#ebeb91:#60827e:#de4974:#38add8:#d6bfb8'
COLORS
