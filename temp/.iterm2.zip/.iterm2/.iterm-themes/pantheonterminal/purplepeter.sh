#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='purplepeter'
cursor-color='#c7c7c7'
foreground='#ece7fa'
background='rgba(42,26,74,.95)'
palette='#0a0520:#ff796d:#99b481:#efdfac:#66d9ef:#e78fcd:#ba8cff:#ffba81:#100b23:#f99f92:#b4be8f:#f2e9bf:#79daed:#ba91d4:#a0a0d6:#b9aed3'
COLORS
