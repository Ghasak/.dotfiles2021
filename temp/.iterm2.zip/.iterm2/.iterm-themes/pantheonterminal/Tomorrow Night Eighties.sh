#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Tomorrow Night Eighties'
cursor-color='#cccccc'
foreground='#cccccc'
background='rgba(45,45,45,.95)'
palette='#000000:#f2777a:#99cc99:#ffcc66:#6699cc:#cc99cc:#66cccc:#ffffff:#000000:#f2777a:#99cc99:#ffcc66:#6699cc:#cc99cc:#66cccc:#ffffff'
COLORS
