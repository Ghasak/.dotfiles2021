#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='N0tch2k'
cursor-color='#aa9175'
foreground='#a0a0a0'
background='rgba(34,34,34,.95)'
palette='#383838:#a95551:#666666:#a98051:#657d3e:#767676:#c9c9c9:#d0b8a3:#474747:#a97775:#8c8c8c:#a99175:#98bd5e:#a3a3a3:#dcdcdc:#d8c8bb'
COLORS
