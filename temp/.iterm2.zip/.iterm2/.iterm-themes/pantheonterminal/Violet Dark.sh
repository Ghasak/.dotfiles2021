#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Violet Dark'
cursor-color='#708284'
foreground='#708284'
background='rgba(28,29,31,.95)'
palette='#56595c:#c94c22:#85981c:#b4881d:#2e8bce:#d13a82:#32a198:#c9c6bd:#45484b:#bd3613:#738a04:#a57705:#2176c7:#c61c6f:#259286:#c9c6bd'
COLORS
