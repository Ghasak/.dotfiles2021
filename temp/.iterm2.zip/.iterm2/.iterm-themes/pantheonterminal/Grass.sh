#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Grass'
cursor-color='#8c2800'
foreground='#fff0a5'
background='rgba(19,119,61,.95)'
palette='#000000:#bb0000:#00bb00:#e7b000:#0000a3:#950062:#00bbbb:#bbbbbb:#555555:#bb0000:#00bb00:#e7b000:#0000bb:#ff55ff:#55ffff:#ffffff'
COLORS
