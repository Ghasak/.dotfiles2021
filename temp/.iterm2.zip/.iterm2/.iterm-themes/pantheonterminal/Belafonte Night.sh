#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Belafonte Night'
cursor-color='#968c83'
foreground='#968c83'
background='rgba(32,17,27,.95)'
palette='#20111b:#be100e:#858162:#eaa549:#426a79:#97522c:#989a9c:#968c83:#5e5252:#be100e:#858162:#eaa549:#426a79:#97522c:#989a9c:#d5ccba'
COLORS
