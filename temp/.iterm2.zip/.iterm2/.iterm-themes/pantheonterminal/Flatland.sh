#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Flatland'
cursor-color='#708284'
foreground='#b8dbef'
background='rgba(29,31,33,.95)'
palette='#1d1d19:#f18339:#9fd364:#f4ef6d:#5096be:#695abc:#d63865:#ffffff:#1d1d19:#d22a24:#a7d42c:#ff8949:#61b9d0:#695abc:#d63865:#ffffff'
COLORS
