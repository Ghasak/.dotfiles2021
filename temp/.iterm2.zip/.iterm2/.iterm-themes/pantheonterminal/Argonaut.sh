#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Argonaut'
cursor-color='#ff0018'
foreground='#fffaf4'
background='rgba(14,16,25,.95)'
palette='#232323:#ff000f:#8ce10b:#ffb900:#008df8:#6d43a6:#00d8eb:#ffffff:#444444:#ff2740:#abe15b:#ffd242:#0092ff:#9a5feb:#67fff0:#ffffff'
COLORS
