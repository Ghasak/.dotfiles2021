#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Ryuuko'
cursor-color='#ececec'
foreground='#ececec'
background='rgba(44,57,65,.95)'
palette='#2c3941:#865f5b:#66907d:#b1a990:#6a8e95:#b18a73:#88b2ac:#ececec:#5d7079:#865f5b:#66907d:#b1a990:#6a8e95:#b18a73:#88b2ac:#ececec'
COLORS
