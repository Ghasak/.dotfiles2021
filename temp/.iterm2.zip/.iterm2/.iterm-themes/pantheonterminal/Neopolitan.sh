#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Neopolitan'
cursor-color='#ffffff'
foreground='#ffffff'
background='rgba(39,31,25,.95)'
palette='#000000:#800000:#61ce3c:#fbde2d:#253b76:#ff0080:#8da6ce:#f8f8f8:#000000:#800000:#61ce3c:#fbde2d:#253b76:#ff0080:#8da6ce:#f8f8f8'
COLORS
