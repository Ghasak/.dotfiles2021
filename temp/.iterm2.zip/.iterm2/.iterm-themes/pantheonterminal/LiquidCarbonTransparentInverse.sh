#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='LiquidCarbonTransparentInverse'
cursor-color='#ffffff'
foreground='#afc2c2'
background='rgba(0,0,0,.95)'
palette='#bccccd:#ff3030:#559a70:#ccac00:#0099cc:#cc69c8:#7ac4cc:#000000:#ffffff:#ff3030:#559a70:#ccac00:#0099cc:#cc69c8:#7ac4cc:#000000'
COLORS
