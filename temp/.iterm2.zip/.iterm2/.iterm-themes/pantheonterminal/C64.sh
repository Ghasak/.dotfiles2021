#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='C64'
cursor-color='#7869c4'
foreground='#7869c4'
background='rgba(64,49,141,.95)'
palette='#090300:#883932:#55a049:#bfce72:#40318d:#8b3f96:#67b6bd:#ffffff:#000000:#883932:#55a049:#bfce72:#40318d:#8b3f96:#67b6bd:#f7f7f7'
COLORS
