#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='ayu'
cursor-color='#f29718'
foreground='#e6e1cf'
background='rgba(15,20,25,.95)'
palette='#000000:#ff3333:#b8cc52:#e7c547:#36a3d9:#f07178:#95e6cb:#ffffff:#323232:#ff6565:#eafe84:#fff779:#68d5ff:#ffa3aa:#c7fffd:#ffffff'
COLORS
