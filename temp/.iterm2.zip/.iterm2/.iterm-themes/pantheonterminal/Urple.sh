#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Urple'
cursor-color='#a063eb'
foreground='#877a9b'
background='rgba(27,27,35,.95)'
palette='#000000:#b0425b:#37a415:#ad5c42:#564d9b:#6c3ca1:#808080:#87799c:#5d3225:#ff6388:#29e620:#f08161:#867aed:#a05eee:#eaeaea:#bfa3ff'
COLORS
