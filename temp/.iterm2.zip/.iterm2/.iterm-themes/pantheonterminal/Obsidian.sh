#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Obsidian'
cursor-color='#c0cad0'
foreground='#cdcdcd'
background='rgba(40,48,51,.95)'
palette='#000000:#a60001:#00bb00:#fecd22:#3a9bdb:#bb00bb:#00bbbb:#bbbbbb:#555555:#ff0003:#93c863:#fef874:#a1d7ff:#ff55ff:#55ffff:#ffffff'
COLORS
