#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Parasio Dark'
cursor-color='#a39e9b'
foreground='#a39e9b'
background='rgba(47,30,46,.95)'
palette='#2f1e2e:#ef6155:#48b685:#fec418:#06b6ef:#815ba4:#5bc4bf:#a39e9b:#776e71:#ef6155:#48b685:#fec418:#06b6ef:#815ba4:#5bc4bf:#e7e9db'
COLORS
