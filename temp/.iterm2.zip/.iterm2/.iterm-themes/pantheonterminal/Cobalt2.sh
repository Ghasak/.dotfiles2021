#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Cobalt2'
cursor-color='#f0cc09'
foreground='#ffffff'
background='rgba(19,39,56,.95)'
palette='#000000:#ff0000:#38de21:#ffe50a:#1460d2:#ff005d:#00bbbb:#bbbbbb:#555555:#f40e17:#3bd01d:#edc809:#5555ff:#ff55ff:#6ae3fa:#ffffff'
COLORS
