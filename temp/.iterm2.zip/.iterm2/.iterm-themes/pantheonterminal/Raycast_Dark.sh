#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Raycast_Dark'
cursor-color='#cccccc'
foreground='#ffffff'
background='rgba(26,26,26,.95)'
palette='#000000:#ff5360:#59d499:#ffc531:#56c2ff:#cf2f98:#52eee5:#ffffff:#000000:#ff6363:#59d499:#ffc531:#56c2ff:#cf2f98:#52eee5:#ffffff'
COLORS
