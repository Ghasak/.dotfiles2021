#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='ENCOM'
cursor-color='#bbbbbb'
foreground='#00a595'
background='rgba(0,0,0,.95)'
palette='#000000:#9f0000:#008b00:#ffd000:#0081ff:#bc00ca:#008b8b:#bbbbbb:#555555:#ff0000:#00ee00:#ffff00:#0000ff:#ff00ff:#00cdcd:#ffffff'
COLORS
