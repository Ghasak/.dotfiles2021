#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Tango Half Adapted'
cursor-color='#000000'
foreground='#000000'
background='rgba(255,255,255,.95)'
palette='#000000:#ff0000:#4cc300:#e2c000:#008ef6:#a96cb3:#00bdc3:#e0e5db:#797d76:#ff0013:#8af600:#ffec00:#76bfff:#d898d1:#00f6fa:#f4f4f2'
COLORS
