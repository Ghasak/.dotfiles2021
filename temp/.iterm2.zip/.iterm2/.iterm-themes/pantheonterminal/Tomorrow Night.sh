#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Tomorrow Night'
cursor-color='#c5c8c6'
foreground='#c5c8c6'
background='rgba(29,31,33,.95)'
palette='#000000:#cc6666:#b5bd68:#f0c674:#81a2be:#b294bb:#8abeb7:#ffffff:#000000:#cc6666:#b5bd68:#f0c674:#81a2be:#b294bb:#8abeb7:#ffffff'
COLORS
