#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='UnderTheSea'
cursor-color='#4afcd6'
foreground='#ffffff'
background='rgba(1,17,22,.95)'
palette='#022026:#b2302d:#00a941:#59819c:#459a86:#00599d:#5d7e19:#405555:#384451:#ff4242:#2aea5e:#8ed4fd:#61d5ba:#1298ff:#98d028:#58fbd6'
COLORS
