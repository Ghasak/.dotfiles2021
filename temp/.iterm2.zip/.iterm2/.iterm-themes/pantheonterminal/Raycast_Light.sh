#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Raycast_Light'
cursor-color='#000000'
foreground='#000000'
background='rgba(255,255,255,.95)'
palette='#000000:#b12424:#006b4f:#f8a300:#138af2:#9a1b6e:#3eb8bf:#ffffff:#000000:#b12424:#006b4f:#f8a300:#138af2:#9a1b6e:#3eb8bf:#ffffff'
COLORS
