#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Brogrammer'
cursor-color='#b9b9b9'
foreground='#d6dbe5'
background='rgba(19,19,19,.95)'
palette='#1f1f1f:#f81118:#2dc55e:#ecba0f:#2a84d2:#4e5ab7:#1081d6:#d6dbe5:#d6dbe5:#de352e:#1dd361:#f3bd09:#1081d6:#5350b9:#0f7ddb:#ffffff'
COLORS
