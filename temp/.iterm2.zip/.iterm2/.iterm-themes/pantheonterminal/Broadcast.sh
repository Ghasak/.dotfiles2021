#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Broadcast'
cursor-color='#ffffff'
foreground='#e6e1dc'
background='rgba(43,43,43,.95)'
palette='#000000:#da4939:#519f50:#ffd24a:#6d9cbe:#d0d0ff:#6e9cbe:#ffffff:#323232:#ff7b6b:#83d182:#ffff7c:#9fcef0:#ffffff:#a0cef0:#ffffff'
COLORS
