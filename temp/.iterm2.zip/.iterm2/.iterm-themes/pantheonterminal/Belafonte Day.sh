#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Belafonte Day'
cursor-color='#45373c'
foreground='#45373c'
background='rgba(213,204,186,.95)'
palette='#20111b:#be100e:#858162:#eaa549:#426a79:#97522c:#989a9c:#968c83:#5e5252:#be100e:#858162:#eaa549:#426a79:#97522c:#989a9c:#d5ccba'
COLORS
