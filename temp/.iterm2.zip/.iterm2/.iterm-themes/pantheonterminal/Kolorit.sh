#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Kolorit'
cursor-color='#c7c7c7'
foreground='#efecec'
background='rgba(29,26,30,.95)'
palette='#1d1a1e:#ff5b82:#47d7a1:#e8e562:#5db4ee:#da6cda:#57e9eb:#ededed:#1d1a1e:#ff5b82:#47d7a1:#e8e562:#5db4ee:#da6cda:#57e9eb:#ededed'
COLORS
