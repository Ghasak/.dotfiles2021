#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='LiquidCarbon'
cursor-color='#ffffff'
foreground='#afc2c2'
background='rgba(48,48,48,.95)'
palette='#000000:#ff3030:#559a70:#ccac00:#0099cc:#cc69c8:#7ac4cc:#bccccc:#000000:#ff3030:#559a70:#ccac00:#0099cc:#cc69c8:#7ac4cc:#bccccc'
COLORS
