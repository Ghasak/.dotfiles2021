#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Symfonic'
cursor-color='#dc322f'
foreground='#ffffff'
background='rgba(0,0,0,.95)'
palette='#000000:#dc322f:#56db3a:#ff8400:#0084d4:#b729d9:#ccccff:#ffffff:#1b1d21:#dc322f:#56db3a:#ff8400:#0084d4:#b729d9:#ccccff:#ffffff'
COLORS
