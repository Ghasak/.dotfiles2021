#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='MaterialDarker'
cursor-color='#ffffff'
foreground='#eeffff'
background='rgba(33,33,33,.95)'
palette='#000000:#ff5370:#c3e88d:#ffcb6b:#82aaff:#c792ea:#89ddff:#ffffff:#545454:#ff5370:#c3e88d:#ffcb6b:#82aaff:#c792ea:#89ddff:#ffffff'
COLORS
