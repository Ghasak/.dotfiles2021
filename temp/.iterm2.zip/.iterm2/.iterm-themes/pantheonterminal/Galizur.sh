#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Galizur'
cursor-color='#ddeeff'
foreground='#ddeeff'
background='rgba(7,19,23,.95)'
palette='#223344:#aa1122:#33aa11:#ccaa22:#2255cc:#7755aa:#22bbdd:#8899aa:#556677:#ff1133:#33ff11:#ffdd33:#3377ff:#aa77ff:#33ddff:#bbccdd'
COLORS
