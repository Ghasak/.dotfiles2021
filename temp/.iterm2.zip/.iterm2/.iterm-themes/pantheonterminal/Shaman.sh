#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Shaman'
cursor-color='#4afcd6'
foreground='#405555'
background='rgba(0,16,21,.95)'
palette='#012026:#b2302d:#00a941:#5e8baa:#449a86:#00599d:#5d7e19:#405555:#384451:#ff4242:#2aea5e:#8ed4fd:#61d5ba:#1298ff:#98d028:#58fbd6'
COLORS
