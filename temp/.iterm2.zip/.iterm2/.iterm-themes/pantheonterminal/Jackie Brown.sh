#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Jackie Brown'
cursor-color='#23ff18'
foreground='#ffcc2f'
background='rgba(44,29,22,.95)'
palette='#2c1d16:#ef5734:#2baf2b:#bebf00:#246eb2:#d05ec1:#00acee:#bfbfbf:#666666:#e50000:#86a93e:#e5e500:#0000ff:#e500e5:#00e5e5:#e5e5e5'
COLORS
