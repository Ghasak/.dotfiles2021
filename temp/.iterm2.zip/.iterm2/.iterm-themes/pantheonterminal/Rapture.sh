#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='Rapture'
cursor-color='#ffffff'
foreground='#c0c9e5'
background='rgba(17,30,42,.95)'
palette='#000000:#fc644d:#7afde1:#fff09b:#6c9bf5:#ff4fa1:#64e0ff:#c0c9e5:#304b66:#fc644d:#7afde1:#fff09b:#6c9bf5:#ff4fa1:#64e0ff:#ffffff'
COLORS
