#!/bin/bash
dconf load /org/pantheon/terminal/settings/ <<COLORS
[/]
name='cyberpunk'
cursor-color='#21f6bc'
foreground='#e5e5e5'
background='rgba(51,42,87,.95)'
palette='#000000:#ff7092:#00fbac:#fffa6a:#00bfff:#df95ff:#86cbfe:#ffffff:#000000:#ff8aa4:#21f6bc:#fff787:#1bccfd:#e6aefe:#99d6fc:#ffffff'
COLORS
