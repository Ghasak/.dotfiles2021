## Default Extensions

- vim
- prettier
- disable ligatures
- tailwind css intellisense
- visual studio intellicode

## Favorite Themes

- github theme
- nomo dark icon theme
- gruvbox material theme
- fira code/jetbrains mono
- vscode custom css and js loader

## Extensions for Collaboration

- gitlens
- restore git branches
