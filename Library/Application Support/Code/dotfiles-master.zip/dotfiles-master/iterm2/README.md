#### Iterm2 Custom Commands
- CMD + J => Previous Pane
- CMD + K => Next Pane
- CMD + CTRL + F => Full Screen
- CMD + CTRL + ENTER => Select Menu Item... Maximize Current Pane
